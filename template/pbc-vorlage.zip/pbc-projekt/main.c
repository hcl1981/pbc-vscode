#include "pbc.h"

int main(void) {
    pbc_init();
    pbc_clear(PBC_BLACK);
    pbc_text24("Hallo!", 80, 120, PBC_WHITE);
    pbc_show();
    while (true) {
        sleep_ms(1000);
    }
}
