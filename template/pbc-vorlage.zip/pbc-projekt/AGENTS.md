# Hinweise für KI-Assistenten (Codex, Claude Code und andere)

Dieses Projekt ist ein C-Programm für den **PicoBoy Color Plus** (PBC+) mit
dem **Raspberry Pi Pico SDK 2.2.0**. Es stammt aus dem Buch „Programmieren
in C – PicoBoy Color Plus und Pico SDK“.

## Hardware

- Mikrocontroller **RP2350** (wie Raspberry Pi Pico 2), 2 Kerne, 150 MHz,
  520 KB RAM, 16 MB Flash. Board-Datei: `pbc/boards/pbc_plus.h`.
- Display ST7789, **240 × 280 Pixel**, (0, 0) oben links, runde Ecken
  (etwa 20 Pixel Rand freilassen).
- Joystick (hoch, runter, links, rechts, hineindrücken = MITTE), Tasten A und B.
- LEDs rot/gelb/grün, eine RGB-LED, Lautsprecher, Neigungssensor.
- Strom aus zwei AAA-Batterien oder über USB-C (Schiebeschalter BAT/USB).
- **Kein** Arduino: keine `setup()`/`loop()`, kein `digitalWrite`, kein
  `Serial.print`. Es gilt das Pico SDK.

## So wird programmiert

- Das Programm steht in **`main.c`**. Es beginnt mit `#include "pbc.h"` und
  ruft in `main` als Erstes `pbc_init()` auf.
- Für Display, Tasten, LEDs, Ton, Sensor und Batteriespannung **nur die Befehle aus
  `pbc/pbc.h`** benutzen. Lies diese Datei, bevor du Code schreibst, und
  erfinde keine weiteren `pbc_…`-Funktionen.
- Zeichnen geht in einen Bildpuffer; sichtbar wird es erst mit
  `pbc_show()` (gut 31 ms). Für Animationen: löschen, zeichnen,
  `pbc_show()`, kurz warten.
- `main` darf nie enden: Am Ende steht eine Endlosschleife
  (`while (true) { … }`), sonst reagiert das Gerät nicht mehr auf USB.
- Warten mit `sleep_ms(ms)`, Zeit mit `pbc_millis()`, Zufall mit
  `pbc_random(min, max)`. Ausgaben mit `printf` über USB, Eingaben mit
  `pbc_input…`.
- Display-Texte nur mit ASCII-Zeichen (keine Umlaute, kein ß).
- Speicher sparsam: keine großen Arrays auf dem Stack (Stack nur 4 KB);
  große Tabellen `static` oder `const`.
- Der Compiler läuft mit `-Wall -Wextra`: Code ohne Warnungen schreiben.
  `MAX`/`MIN` sind schon SDK-Makros (keine eigenen `#define` mit diesen
  Namen); `uint32_t` mit `%lu` und `(unsigned long)` ausgeben.
- `pbc/`, `CMakeLists.txt` und `pico_sdk_import.cmake` nur ändern, wenn
  ausdrücklich danach gefragt wird.

## Bauen und Aufspielen

- Bauen: `cmake -B build && cmake --build build` (oder in VS Code
  **Compile**). Ergebnis: `build/mein_programm.uf2`.
- Aufspielen macht der Mensch (VS Code **Run** oder Bootmodus: BOOT halten,
  RES tippen, `.uf2` aufs Laufwerk kopieren).
- Erkläre Änderungen in einfachen Worten: Der Mensch am anderen Ende lernt
  gerade programmieren.
