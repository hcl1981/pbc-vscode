cmake_minimum_required(VERSION 3.13)

# == DO NOT EDIT THE FOLLOWING LINES for the Raspberry Pi Pico VS Code Extension to work ==
if(WIN32)
    set(USERHOME $ENV{USERPROFILE})
else()
    set(USERHOME $ENV{HOME})
endif()
set(sdkVersion 2.2.0)
set(toolchainVersion 14_2_Rel1)
set(picotoolVersion 2.2.0)
set(picoVscode ${USERHOME}/.pico-sdk/cmake/pico-vscode.cmake)
if (EXISTS ${picoVscode})
    include(${picoVscode})
endif()
# ====================================================================================

# Der PicoBoy Color Plus: Board-Datei in pbc/boards/pbc_plus.h
set(PICO_BOARD_HEADER_DIRS ${CMAKE_CURRENT_LIST_DIR}/pbc/boards)
set(PICO_BOARD pbc_plus CACHE STRING "Board type")

include(pico_sdk_import.cmake)

project(mein_programm C CXX ASM)
set(CMAKE_C_STANDARD 11)
pico_sdk_init()

add_subdirectory(pbc)

add_executable(mein_programm main.c)
target_link_libraries(mein_programm pbc)

# Der Compiler soll auf verdächtige Stellen hinweisen (Warnungen).
target_compile_options(mein_programm PRIVATE -Wall -Wextra)

# Beim Start bis zu 2 Sekunden warten, ob sich ein serieller Monitor
# verbindet – sonst gingen die ersten printf-Ausgaben verloren.
target_compile_definitions(mein_programm PRIVATE PICO_STDIO_USB_CONNECT_WAIT_TIMEOUT_MS=2000)

# printf und Eingaben über USB. Die serielle Schnittstelle (UART) bleibt aus:
# Sie läge auf GP0/GP1 – dort hängen Joystick-Mitte und -Rechts.
pico_enable_stdio_usb(mein_programm 1)
pico_enable_stdio_uart(mein_programm 0)

# Erzeugt neben der .elf auch die .uf2-Datei zum Aufspielen.
pico_add_extra_outputs(mein_programm)
