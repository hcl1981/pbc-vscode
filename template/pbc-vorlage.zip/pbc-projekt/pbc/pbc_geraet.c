// pbc_geraet.c – der Teil der Buchbibliothek, der die Hardware bedient
//
// Grundlage sind die Treiber der MicroPython-Firmware des PicoBoy Color Plus.
// Teil IV des Buchs erklärt jeden Abschnitt dieser Datei.

#include "pbc.h"
#include "pbc_intern.h"

#include "hardware/adc.h"
#include "hardware/clocks.h"
#include "hardware/dma.h"
#include "hardware/gpio.h"
#include "hardware/i2c.h"
#include "hardware/pio.h"
#include "hardware/pwm.h"
#include "hardware/spi.h"
#include "pico/rand.h"

// ---- Pinbelegung ------------------------------------------------------------

#define PIN_TASTE_HOCH     4
#define PIN_TASTE_RUNTER   2
#define PIN_TASTE_LINKS    3
#define PIN_TASTE_RECHTS   1
#define PIN_TASTE_MITTE    0
#define PIN_TASTE_A       27
#define PIN_TASTE_B       28

#define PIN_LED_ROT       14
#define PIN_LED_GELB      13
#define PIN_LED_GRUEN     12
#define PIN_RGB_LED       11

#define PIN_LAUTSPRECHER  15

#define PIN_SPI_SCK       18
#define PIN_SPI_MOSI      19
#define PIN_DISPLAY_CS    10
#define PIN_DISPLAY_DC     8
#define PIN_DISPLAY_RST    9
#define PIN_DISPLAY_LICHT 26

#define PIN_I2C_SDA       20
#define PIN_I2C_SCL       21

#define PIN_AKKU          29   // ADC-Eingang 3

// ---- Display (ST7789 an SPI0) ---------------------------------------------------

#define DISPLAY_Y_VERSATZ 20   // sichtbar sind die Zeilen 20 bis 299 des Controllers

static int display_dma = -1;

static void display_befehl(uint8_t befehl, const uint8_t *daten, size_t laenge) {
    spi_set_format(spi0, 8, SPI_CPOL_0, SPI_CPHA_0, SPI_MSB_FIRST);
    gpio_put(PIN_DISPLAY_CS, 0);
    gpio_put(PIN_DISPLAY_DC, 0);                  // DC = 0: Befehl
    spi_write_blocking(spi0, &befehl, 1);
    if (laenge > 0) {
        gpio_put(PIN_DISPLAY_DC, 1);              // DC = 1: Daten
        spi_write_blocking(spi0, daten, laenge);
    }
    gpio_put(PIN_DISPLAY_CS, 1);
}

static void display_fenster(int x0, int y0, int x1, int y1) {
    y0 += DISPLAY_Y_VERSATZ;
    y1 += DISPLAY_Y_VERSATZ;
    uint8_t spalten[4] = { x0 >> 8, x0 & 0xFF, x1 >> 8, x1 & 0xFF };
    uint8_t zeilen[4] = { y0 >> 8, y0 & 0xFF, y1 >> 8, y1 & 0xFF };
    display_befehl(0x2A, spalten, 4);             // CASET: Spalten
    display_befehl(0x2B, zeilen, 4);              // RASET: Zeilen
    display_befehl(0x2C, NULL, 0);                // RAMWR: jetzt kommen Pixel
}

static void display_init(void) {
    gpio_init(PIN_DISPLAY_CS);  gpio_set_dir(PIN_DISPLAY_CS, GPIO_OUT);  gpio_put(PIN_DISPLAY_CS, 1);
    gpio_init(PIN_DISPLAY_DC);  gpio_set_dir(PIN_DISPLAY_DC, GPIO_OUT);  gpio_put(PIN_DISPLAY_DC, 1);
    gpio_init(PIN_DISPLAY_RST); gpio_set_dir(PIN_DISPLAY_RST, GPIO_OUT); gpio_put(PIN_DISPLAY_RST, 1);

    spi_init(spi0, 62500000);
    gpio_set_function(PIN_SPI_SCK, GPIO_FUNC_SPI);
    gpio_set_function(PIN_SPI_MOSI, GPIO_FUNC_SPI);

    // Hardware-Reset
    sleep_ms(10);
    gpio_put(PIN_DISPLAY_RST, 0);
    sleep_ms(50);
    gpio_put(PIN_DISPLAY_RST, 1);
    sleep_ms(150);

    display_befehl(0x01, NULL, 0);                // SWRESET
    sleep_ms(150);
    display_befehl(0x11, NULL, 0);                // SLPOUT: aufwachen
    sleep_ms(120);
    uint8_t colmod = 0x55;                        // 16 Bit pro Pixel (RGB565)
    display_befehl(0x3A, &colmod, 1);
    uint8_t madctl = 0xC0;                        // um 180° gedreht
    display_befehl(0x36, &madctl, 1);
    display_befehl(0x21, NULL, 0);                // INVON: dieses Panel braucht Invertierung
    sleep_ms(10);
    display_befehl(0x13, NULL, 0);                // NORON
    sleep_ms(10);
    display_befehl(0x29, NULL, 0);                // DISPON
    sleep_ms(100);

    display_dma = dma_claim_unused_channel(true);

    // Hintergrundlicht per PWM, erst einmal aus
    gpio_set_function(PIN_DISPLAY_LICHT, GPIO_FUNC_PWM);
    uint slice = pwm_gpio_to_slice_num(PIN_DISPLAY_LICHT);
    pwm_config cfg = pwm_get_default_config();
    pwm_config_set_wrap(&cfg, 255);
    pwm_init(slice, &cfg, true);
    pwm_set_gpio_level(PIN_DISPLAY_LICHT, 0);
}

// Schickt den ganzen Bildpuffer per DMA ans Display. spi_init bestellt
// 62,5 MHz; der Teiler des RP2350 erreicht davon 37,5 MHz, ein Bild
// (240 × 280 × 16 Bit) dauert gerechnet 28,7 ms, gemessen 31,4 ms.
// Mit 16-Bit-SPI geht jedes Pixel mit dem höheren Byte zuerst hinaus,
// so wie der ST7789 es erwartet.
void pbc_show(void) {
    display_fenster(0, 0, PBC_WIDTH - 1, PBC_HEIGHT - 1);
    spi_set_format(spi0, 16, SPI_CPOL_0, SPI_CPHA_0, SPI_MSB_FIRST);
    gpio_put(PIN_DISPLAY_CS, 0);
    gpio_put(PIN_DISPLAY_DC, 1);
    dma_channel_config c = dma_channel_get_default_config(display_dma);
    channel_config_set_transfer_data_size(&c, DMA_SIZE_16);
    channel_config_set_read_increment(&c, true);
    channel_config_set_write_increment(&c, false);
    channel_config_set_dreq(&c, spi_get_dreq(spi0, true));
    dma_channel_configure(display_dma, &c, &spi_get_hw(spi0)->dr, pbc_bildpuffer,
                          PBC_WIDTH * PBC_HEIGHT, true);
    dma_channel_wait_for_finish_blocking(display_dma);
    while (spi_is_busy(spi0)) tight_loop_contents();
    gpio_put(PIN_DISPLAY_CS, 1);
}

void pbc_backlight(int value) {
    if (value < 0) value = 0;
    if (value > 255) value = 255;
    pwm_set_gpio_level(PIN_DISPLAY_LICHT, (uint16_t)value);
}

// ---- Tasten ---------------------------------------------------------------------
//
// Alle Tasten verbinden ihren Pin beim Drücken mit GND (aktiv LOW); ein
// interner Pull-up-Widerstand hält ihn sonst auf HIGH. Ein Interrupt sieht
// Drücken und Loslassen, damit pbc_was_pressed_…() keinen Druck verpasst.

enum { HOCH, RUNTER, LINKS, RECHTS, MITTE, TASTE_A, TASTE_B, ANZAHL_TASTEN };

static const uint8_t tasten_pins[ANZAHL_TASTEN] = {
    PIN_TASTE_HOCH, PIN_TASTE_RUNTER, PIN_TASTE_LINKS, PIN_TASTE_RECHTS,
    PIN_TASTE_MITTE, PIN_TASTE_A, PIN_TASTE_B,
};
static volatile bool tasten_gemerkt[ANZAHL_TASTEN];
static volatile uint32_t tasten_zuletzt_ms[ANZAHL_TASTEN];

#define ENTPRELLEN_MS 50

static void tasten_interrupt(void) {
    for (int i = 0; i < ANZAHL_TASTEN; i++) {
        uint32_t ereignisse = gpio_get_irq_event_mask(tasten_pins[i]);
        if (ereignisse == 0) continue;
        gpio_acknowledge_irq(tasten_pins[i], ereignisse);
        uint32_t jetzt = to_ms_since_boot(get_absolute_time());
        bool ruhig = jetzt - tasten_zuletzt_ms[i] >= ENTPRELLEN_MS;
        tasten_zuletzt_ms[i] = jetzt;      // jede Flanke, auch beim Loslassen
        if (ruhig && (ereignisse & GPIO_IRQ_EDGE_FALL)) tasten_gemerkt[i] = true;
    }
}

static void tasten_init(void) {
    uint32_t maske = 0;
    for (int i = 0; i < ANZAHL_TASTEN; i++) {
        gpio_init(tasten_pins[i]);
        gpio_set_dir(tasten_pins[i], GPIO_IN);
        gpio_pull_up(tasten_pins[i]);
        maske |= 1u << tasten_pins[i];
    }
    // Ein "roher" Handler nur für die sieben Tastenpins. Achtung: Der
    // Standard-Handler des SDK überspringt Pins mit rohem Handler; für die
    // Tasten liefert gpio_set_irq_callback() nach pbc_init() deshalb nichts.
    // Für alle anderen Pins bleibt er frei (Kapitel 24).
    gpio_add_raw_irq_handler_masked(maske, tasten_interrupt);
    for (int i = 0; i < ANZAHL_TASTEN; i++) {
        gpio_set_irq_enabled(tasten_pins[i], GPIO_IRQ_EDGE_FALL | GPIO_IRQ_EDGE_RISE, true);
    }
    irq_set_enabled(IO_IRQ_BANK0, true);
}

static bool gedrueckt(int i) { return !gpio_get(tasten_pins[i]); }

static bool war_gedrueckt(int i) {
    bool war = tasten_gemerkt[i];
    tasten_gemerkt[i] = false;
    return war;
}

bool pbc_pressed_up(void) { return gedrueckt(HOCH); }
bool pbc_pressed_down(void) { return gedrueckt(RUNTER); }
bool pbc_pressed_left(void) { return gedrueckt(LINKS); }
bool pbc_pressed_right(void) { return gedrueckt(RECHTS); }
bool pbc_pressed_center(void) { return gedrueckt(MITTE); }
bool pbc_pressed_a(void) { return gedrueckt(TASTE_A); }
bool pbc_pressed_b(void) { return gedrueckt(TASTE_B); }

bool pbc_any_pressed(void) {
    for (int i = 0; i < ANZAHL_TASTEN; i++) if (gedrueckt(i)) return true;
    return false;
}

bool pbc_was_pressed_up(void) { return war_gedrueckt(HOCH); }
bool pbc_was_pressed_down(void) { return war_gedrueckt(RUNTER); }
bool pbc_was_pressed_left(void) { return war_gedrueckt(LINKS); }
bool pbc_was_pressed_right(void) { return war_gedrueckt(RECHTS); }
bool pbc_was_pressed_center(void) { return war_gedrueckt(MITTE); }
bool pbc_was_pressed_a(void) { return war_gedrueckt(TASTE_A); }
bool pbc_was_pressed_b(void) { return war_gedrueckt(TASTE_B); }

void pbc_wait_for_button(void) {
    while (!pbc_any_pressed()) sleep_ms(10);
    while (pbc_any_pressed()) sleep_ms(10);
    // Den abgewarteten Druck verbrauchen, damit ihn pbc_was_pressed_…()
    // nicht später noch einmal meldet.
    for (int i = 0; i < ANZAHL_TASTEN; i++) tasten_gemerkt[i] = false;
}

// ---- Status-LEDs (aktiv HIGH) -------------------------------------------------------

static void led_init(uint pin) {
    gpio_init(pin);
    gpio_set_dir(pin, GPIO_OUT);
    gpio_put(pin, 0);
}

void pbc_led_red(bool on) { gpio_put(PIN_LED_ROT, on); }
void pbc_led_yellow(bool on) { gpio_put(PIN_LED_GELB, on); }
void pbc_led_green(bool on) { gpio_put(PIN_LED_GRUEN, on); }
void pbc_leds_off(void) {
    pbc_led_red(false);
    pbc_led_yellow(false);
    pbc_led_green(false);
}

// ---- RGB-LED (SK6805, WS2812-kompatibel) über PIO ------------------------------------
//
// Die LED erwartet 24 Bit (Grün, Rot, Blau) als Pulse mit genauem Timing:
// kurzer HIGH-Puls = 0, langer HIGH-Puls = 1. Das erledigt ein kleines
// PIO-Programm aus 4 Befehlen (dasselbe wie in den pico-examples):
//     out  x, 1   side 0 [2]
//     jmp !x, 3   side 1 [1]
//     jmp 0       side 1 [4]
//     nop         side 0 [4]

static const uint16_t ws2812_befehle[] = { 0x6221, 0x1123, 0x1400, 0xa442 };
static const struct pio_program ws2812_programm = {
    .instructions = ws2812_befehle, .length = 4, .origin = -1,
};
static PIO rgb_pio = NULL;
static int rgb_sm = -1;

static void rgb_init(void) {
    rgb_pio = pio0;
    if (!pio_can_add_program(rgb_pio, &ws2812_programm)) rgb_pio = pio1;
    rgb_sm = pio_claim_unused_sm(rgb_pio, true);
    uint offset = pio_add_program(rgb_pio, &ws2812_programm);
    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_wrap(&c, offset, offset + ws2812_programm.length - 1);
    sm_config_set_sideset(&c, 1, false, false);
    sm_config_set_sideset_pins(&c, PIN_RGB_LED);
    sm_config_set_out_shift(&c, false, true, 24);
    sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);
    sm_config_set_clkdiv(&c, (float)clock_get_hz(clk_sys) / (800000.0f * 10.0f));
    pio_gpio_init(rgb_pio, PIN_RGB_LED);
    pio_sm_set_consecutive_pindirs(rgb_pio, rgb_sm, PIN_RGB_LED, 1, true);
    pio_sm_init(rgb_pio, rgb_sm, offset, &c);
    pio_sm_set_enabled(rgb_pio, rgb_sm, true);
}

static uint8_t begrenzen(int wert) {
    return wert < 0 ? 0 : wert > 255 ? 255 : (uint8_t)wert;
}

void pbc_rgb_led(int r, int g, int b) {
    uint32_t grb = ((uint32_t)begrenzen(g) << 16) | ((uint32_t)begrenzen(r) << 8) | begrenzen(b);
    pio_sm_put_blocking(rgb_pio, rgb_sm, grb << 8);
}

void pbc_rgb_led_off(void) { pbc_rgb_led(0, 0, 0); }

// ---- Ton: PWM auf dem Lautsprecher-Pin --------------------------------------------------

static alarm_id_t ton_wecker = 0;

static int64_t ton_ende(alarm_id_t id, void *daten) {
    (void)id; (void)daten;
    ton_wecker = 0;
    pbc_tone_off();
    return 0;
}

void pbc_tone(int frequency, int ms) {
    if (ton_wecker) { cancel_alarm(ton_wecker); ton_wecker = 0; }
    if (frequency <= 0) { pbc_tone_off(); return; }
    if (frequency < 20) frequency = 20;
    if (frequency > 20000) frequency = 20000;
    uint slice = pwm_gpio_to_slice_num(PIN_LAUTSPRECHER);
    uint kanal = pwm_gpio_to_channel(PIN_LAUTSPRECHER);
    // Takt / (Teiler × (wrap + 1)) = Frequenz; wrap möglichst groß für feine Stufen
    uint32_t wrap = 1000;
    float teiler = (float)clock_get_hz(clk_sys) / ((float)frequency * (wrap + 1));
    while (teiler > 255.0f && wrap < 32768) {
        wrap *= 2;
        teiler = (float)clock_get_hz(clk_sys) / ((float)frequency * (wrap + 1));
    }
    if (teiler < 1.0f) teiler = 1.0f;
    if (teiler > 255.9f) teiler = 255.9f;
    gpio_set_function(PIN_LAUTSPRECHER, GPIO_FUNC_PWM);
    pwm_set_clkdiv(slice, teiler);
    pwm_set_wrap(slice, (uint16_t)wrap);
    pwm_set_chan_level(slice, kanal, (uint16_t)((wrap + 1) / 2));   // halb an, halb aus
    pwm_set_enabled(slice, true);
    if (ms > 0) ton_wecker = add_alarm_in_ms(ms, ton_ende, NULL, true);
}

void pbc_tone_off(void) {
    if (ton_wecker) { cancel_alarm(ton_wecker); ton_wecker = 0; }
    pwm_set_enabled(pwm_gpio_to_slice_num(PIN_LAUTSPRECHER), false);
    // Pin auf LOW legen, damit der Lautsprecher nicht auf halber Spannung hängt
    gpio_set_function(PIN_LAUTSPRECHER, GPIO_FUNC_SIO);
    gpio_set_dir(PIN_LAUTSPRECHER, GPIO_OUT);
    gpio_put(PIN_LAUTSPRECHER, 0);
}

// ---- Neigungssensor STK8BA58 an I2C0 ----------------------------------------------------

#define SENSOR_ADRESSE 0x18
static bool sensor_da = false;

static int sensor_lesen(uint8_t reg, uint8_t *puffer, size_t laenge) {
    int r = i2c_write_blocking(i2c0, SENSOR_ADRESSE, &reg, 1, true);
    if (r < 0) return r;
    return i2c_read_blocking(i2c0, SENSOR_ADRESSE, puffer, laenge, false);
}

static void sensor_schreiben(uint8_t reg, uint8_t wert) {
    uint8_t puffer[2] = { reg, wert };
    i2c_write_blocking(i2c0, SENSOR_ADRESSE, puffer, 2, false);
}

static void sensor_init(void) {
    i2c_init(i2c0, 400000);
    gpio_set_function(PIN_I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(PIN_I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(PIN_I2C_SDA);
    gpio_pull_up(PIN_I2C_SCL);
    uint8_t id;
    if (sensor_lesen(0x00, &id, 1) < 0) return;   // antwortet der Sensor?
    sensor_schreiben(0x0F, 0x03);                  // Messbereich ±2 g
    sensor_schreiben(0x10, 0x0C);                  // Bandbreite 125 Hz
    sensor_schreiben(0x11, 0x00);                  // normaler Betrieb
    sensor_da = true;
}

// Eine Achse: Der Chip liefert 12 Bit, linksbündig in zwei Registern (1024
// Stufen pro g bei ±2 g). Hier werden nur die oberen 10 Bit benutzt
// (256 Stufen pro g) – für Spiele fein genug; Kapitel 22 zeigt alle 12.
static float achse_g(uint8_t reg) {
    uint8_t b[2];
    if (!sensor_da || sensor_lesen(reg, b, 2) < 0) return 0.0f;
    int16_t roh = (int16_t)((b[1] << 8) | b[0]);
    return (float)(roh >> 6) * 2.0f / 512.0f;
}

// Der Chip liegt gedreht auf der Platine: x und y vertauscht, Vorzeichen anders.
float pbc_accel_x_g(void) { return achse_g(0x04); }
float pbc_accel_y_g(void) { return -achse_g(0x02); }
float pbc_accel_z_g(void) { return -achse_g(0x06); }
float pbc_accel_x(void) { return pbc_accel_x_g() * 9.80665f; }
float pbc_accel_y(void) { return pbc_accel_y_g() * 9.80665f; }
float pbc_accel_z(void) { return pbc_accel_z_g() * 9.80665f; }

// ---- Batterie (2 × AAA) bzw. USB: Spannungsteiler 1:3 an ADC-Eingang 3 -----------------------

static void akku_init(void) {
    adc_init();
    adc_gpio_init(PIN_AKKU);
    sleep_ms(50);                 // Kondensator am Teiler aufladen lassen
    adc_select_input(3);
    for (int i = 0; i < 8; i++) adc_read();
}

float pbc_battery_voltage(void) {
    adc_select_input(3);
    adc_read();
    adc_read();
    uint32_t summe = 0;
    for (int i = 0; i < 16; i++) summe += adc_read();
    float am_pin = (summe / 16.0f) * 3.3f / 4095.0f;
    return am_pin * 3.0f;
}

bool pbc_is_on_usb(void) { return pbc_battery_voltage() > 4.0f; }

// ---- Zeit, Zufall, Konsole ---------------------------------------------------------------------

uint32_t pbc_millis(void) { return to_ms_since_boot(get_absolute_time()); }

uint32_t pbc_zufall32(void) { return get_rand_32(); }

int pbc_zeichen_lesen(void) { return getchar(); }

// ---- Start ------------------------------------------------------------------------------------

void pbc_init(void) {
    stdio_init_all();             // printf über USB (wartet kurz auf den seriellen Monitor)
    led_init(PIN_LED_ROT);
    led_init(PIN_LED_GELB);
    led_init(PIN_LED_GRUEN);
    pbc_tone_off();
    tasten_init();
    rgb_init();
    pbc_rgb_led_off();
    sensor_init();
    akku_init();
    display_init();
    pbc_clear(PBC_BLACK);
    pbc_show();
    pbc_backlight(255);           // erst jetzt, sonst sieht man kurz Pixelmüll
}
