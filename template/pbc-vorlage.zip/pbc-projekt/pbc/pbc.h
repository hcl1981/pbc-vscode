// pbc.h – die Buchbibliothek für den PicoBoy Color Plus
//
// Eine kleine Sammlung von Befehlen für Display, Tasten, LEDs, Ton,
// Neigungssensor und Batteriespannung. Die Namen entsprechen dem Python-Modul pbc:
// Aus pbc.fill_rect(...) wird pbc_fill_rect(...), aus pbc.RED wird PBC_RED.
//
// Wichtig: Alles Gezeichnete landet zuerst in einem Bildpuffer im Speicher.
// Erst pbc_show() schickt das ganze Bild auf einmal ans Display. Dadurch
// flackert nichts.
//
// Koordinaten: (0, 0) ist oben links, x wächst nach rechts, y nach unten.
// Das Display hat PBC_WIDTH × PBC_HEIGHT = 240 × 280 Pixel und runde Ecken.

#ifndef PBC_H
#define PBC_H

// Damit reicht in den Programmen des Buchs ein einziges #include "pbc.h".
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pico/stdlib.h"

#ifdef __cplusplus
extern "C" {
#endif

// ---- Start ----------------------------------------------------------------

// Muss als Erstes in main() stehen: richtet Display, Tasten, LEDs, Ton,
// Sensor und die Konsole (printf über USB) ein.
void pbc_init(void);

// ---- Display --------------------------------------------------------------

#define PBC_WIDTH  240
#define PBC_HEIGHT 280

// Farben im Format RGB565: 5 Bit Rot, 6 Bit Grün, 5 Bit Blau in 16 Bit.
#define PBC_BLACK     0x0000
#define PBC_WHITE     0xFFFF
#define PBC_RED       0xF800
#define PBC_GREEN     0x07E0
#define PBC_BLUE      0x001F
#define PBC_YELLOW    0xFFE0
#define PBC_CYAN      0x07FF
#define PBC_MAGENTA   0xF81F
#define PBC_ORANGE    0xFD20
#define PBC_PURPLE    0x780F
#define PBC_GRAY      0x8410

// Eigene Farbe aus Rot, Grün, Blau (je 0 bis 255).
uint16_t pbc_rgb(int r, int g, int b);

// Das Bild aus dem Bildpuffer aufs Display bringen.
void pbc_show(void);

void pbc_clear(uint16_t color);                     // ganzes Bild füllen
void pbc_pixel(int x, int y, uint16_t color);
uint16_t pbc_get_pixel(int x, int y);               // Farbe im Bildpuffer lesen
void pbc_line(int x1, int y1, int x2, int y2, uint16_t color);
void pbc_hline(int x, int y, int length, uint16_t color);
void pbc_vline(int x, int y, int length, uint16_t color);
void pbc_rect(int x, int y, int w, int h, uint16_t color);       // Umriss
void pbc_fill_rect(int x, int y, int w, int h, uint16_t color);  // gefüllt
void pbc_ellipse(int mx, int my, int rx, int ry, uint16_t color);
void pbc_fill_ellipse(int mx, int my, int rx, int ry, uint16_t color);
void pbc_circle(int mx, int my, int r, uint16_t color);
void pbc_fill_circle(int mx, int my, int r, uint16_t color);

// Text. (x, y) ist die linke obere Ecke. Der Rückgabewert ist die
// x-Position direkt hinter dem Text. Nur die Zeichen von ASCII 32 bis 126;
// Umlaute erscheinen als '?'.
int pbc_text(const char *s, int x, int y, uint16_t color);     // 8 × 8, feste Breite
int pbc_text12(const char *s, int x, int y, uint16_t color);   // Zeile 16 px hoch
int pbc_text18(const char *s, int x, int y, uint16_t color);   // Zeile 24 px hoch
int pbc_text24(const char *s, int x, int y, uint16_t color);   // Zeile 32 px hoch
int pbc_text_width(const char *s);                             // Breite in Pixeln
int pbc_text12_width(const char *s);
int pbc_text18_width(const char *s);
int pbc_text24_width(const char *s);

// Ein Bild als C-Array, erzeugt vom Umwandlungswerkzeug (Kapitel 15).
typedef struct {
    int width;
    int height;
    const uint16_t *pixels;   // width × height Farben, zeilenweise
    const uint8_t *mask;      // 1 = sichtbar, 0 = durchsichtig; NULL: alles sichtbar
} pbc_image;

void pbc_draw_image(const pbc_image *image, int x, int y);

// Helligkeit des Displays, 0 (aus) bis 255 (voll).
void pbc_backlight(int value);

// ---- Tasten und Joystick ----------------------------------------------

// true, solange die Taste gedrückt ist.
bool pbc_pressed_up(void);
bool pbc_pressed_down(void);
bool pbc_pressed_left(void);
bool pbc_pressed_right(void);
bool pbc_pressed_center(void);   // Joystick hineindrücken
bool pbc_pressed_a(void);
bool pbc_pressed_b(void);
bool pbc_any_pressed(void);

// true genau einmal pro Druck (die Bibliothek merkt sich jeden Druck,
// auch wenn das Programm gerade beschäftigt war).
bool pbc_was_pressed_up(void);
bool pbc_was_pressed_down(void);
bool pbc_was_pressed_left(void);
bool pbc_was_pressed_right(void);
bool pbc_was_pressed_center(void);
bool pbc_was_pressed_a(void);
bool pbc_was_pressed_b(void);

// Wartet, bis eine Taste gedrückt und wieder losgelassen wurde.
void pbc_wait_for_button(void);

// ---- LEDs ---------------------------------------------------------------

void pbc_led_red(bool on);
void pbc_led_yellow(bool on);
void pbc_led_green(bool on);
void pbc_leds_off(void);

void pbc_rgb_led(int r, int g, int b);   // je 0 bis 255
void pbc_rgb_led_off(void);

// ---- Ton ----------------------------------------------------------------

// Spielt einen Ton mit der Frequenz in Hertz. ms = Dauer in Millisekunden,
// 0 = bis pbc_tone_off(). Wartet NICHT: Das Programm läuft sofort weiter.
void pbc_tone(int frequency, int ms);
void pbc_tone_off(void);

// ---- Neigungssensor -------------------------------------------------------

// Beschleunigung in m/s². Flach auf dem Tisch: x = 0, y = 0, z = 9,81.
// +x zeigt nach rechts, +y nach unten (zum Joystick), +z aus dem Display.
float pbc_accel_x(void);
float pbc_accel_y(void);
float pbc_accel_z(void);
// Dasselbe in g (1 g = 9,81 m/s²).
float pbc_accel_x_g(void);
float pbc_accel_y_g(void);
float pbc_accel_z_g(void);

// ---- Batterie ------------------------------------------------------------

float pbc_battery_voltage(void);   // in Volt; am USB etwa 5 V
bool pbc_is_on_usb(void);

// ---- Zeit, Zufall, Konsole ------------------------------------------------

// Millisekunden seit dem Start. Warten geht mit sleep_ms(ms) aus dem SDK.
uint32_t pbc_millis(void);

// Zufällige ganze Zahl von min bis max (beide eingeschlossen).
int pbc_random(int min, int max);

// Liest eine Zeile aus der Konsole (seriellen Monitor). Zeigt vorher den
// Text prompt an und wartet, bis Enter gedrückt wird. Die Eingabe steht
// danach in text (höchstens size - 1 Zeichen).
void pbc_input(const char *prompt, char *text, int size);
int pbc_input_int(const char *prompt);      // liest eine ganze Zahl
float pbc_input_float(const char *prompt);  // liest eine Kommazahl (Punkt oder Komma)

#ifdef __cplusplus
}
#endif

#endif // PBC_H
