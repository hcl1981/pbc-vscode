# Die Buchbibliothek pbc als eigene Bibliothek, die main.c dazubindet.
add_library(pbc STATIC
    pbc_zeichnen.c
    pbc_geraet.c
)
target_include_directories(pbc PUBLIC ${CMAKE_CURRENT_LIST_DIR})
target_link_libraries(pbc PUBLIC
    pico_stdlib
    pico_rand
    hardware_adc
    hardware_dma
    hardware_i2c
    hardware_pio
    hardware_pwm
    hardware_spi
)
