// Board-Datei für den PicoBoy Color Plus.
// Alles wie beim Raspberry Pi Pico 2 (RP2350A), nur mit 16 MB Flash,
// 4 KB Stack und ohne die Pico-LED an GP25.

pico_board_cmake_set(PICO_PLATFORM, rp2350)
pico_board_cmake_set_default(PICO_FLASH_SIZE_BYTES, (16 * 1024 * 1024))
// Wie beim Pico 2: UF2-Dateien bekommen den Zusatzblock für Chips der
// Revision A2 (Erratum RP2350-E10), damit Drag & Drop dort sicher klappt.
pico_board_cmake_set_default(PICO_RP2350_A2_SUPPORTED, 1)

#ifndef _BOARDS_PBC_PLUS_H
#define _BOARDS_PBC_PLUS_H

#define PICO_FLASH_SIZE_BYTES (16 * 1024 * 1024)
#include "boards/pico2.h"
#undef PICO_DEFAULT_LED_PIN

// Der Stack liegt in einem eigenen 4-KB-Speicherbereich; das SDK nutzt
// sonst nur die Hälfte davon. Läuft er trotzdem über, hält ein Wächter
// das Programm an, statt still andere Daten zu überschreiben.
#define PICO_STACK_SIZE 0x1000
#define PICO_USE_STACK_GUARDS 1

#endif
