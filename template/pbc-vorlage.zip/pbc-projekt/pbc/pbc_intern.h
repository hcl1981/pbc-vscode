// pbc_intern.h – was die Teile der Bibliothek untereinander teilen.
// Programme brauchen diese Datei nicht.

#ifndef PBC_INTERN_H
#define PBC_INTERN_H

#include <stdint.h>
#include "pbc.h"

// Der Bildpuffer: PBC_WIDTH × PBC_HEIGHT Farben, Zeile für Zeile.
extern uint16_t pbc_bildpuffer[PBC_WIDTH * PBC_HEIGHT];

// Vom Geräte- bzw. PC-Teil geliefert:
uint32_t pbc_zufall32(void);      // 32 zufällige Bits
int pbc_zeichen_lesen(void);      // wartet auf ein Zeichen aus der Konsole

#endif // PBC_INTERN_H
