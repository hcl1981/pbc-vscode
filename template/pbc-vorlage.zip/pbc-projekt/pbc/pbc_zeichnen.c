// pbc_zeichnen.c – alles, was in den Bildpuffer zeichnet
//
// Dieser Teil kennt keine Hardware: Er schreibt nur Zahlen in das Feld
// pbc_bildpuffer. Linien, Ellipsen und Schriften zeichnen dieselben Pixel
// wie pbc in MicroPython auf einem Canvas.

#include "pbc.h"
#include "pbc_intern.h"
#include "schrift8.h"
#include "schrift12.h"
#include "schrift18.h"
#include "schrift24.h"

uint16_t pbc_bildpuffer[PBC_WIDTH * PBC_HEIGHT];

uint16_t pbc_rgb(int r, int g, int b) {
    if (r < 0) r = 0;
    if (r > 255) r = 255;
    if (g < 0) g = 0;
    if (g > 255) g = 255;
    if (b < 0) b = 0;
    if (b > 255) b = 255;
    return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}

// ---- Punkte und Linien ------------------------------------------------------

void pbc_pixel(int x, int y, uint16_t color) {
    if (x < 0 || x >= PBC_WIDTH || y < 0 || y >= PBC_HEIGHT) return;
    pbc_bildpuffer[y * PBC_WIDTH + x] = color;
}

uint16_t pbc_get_pixel(int x, int y) {
    if (x < 0 || x >= PBC_WIDTH || y < 0 || y >= PBC_HEIGHT) return 0;
    return pbc_bildpuffer[y * PBC_WIDTH + x];
}

void pbc_clear(uint16_t color) {
    for (int i = 0; i < PBC_WIDTH * PBC_HEIGHT; i++) pbc_bildpuffer[i] = color;
}

void pbc_hline(int x, int y, int length, uint16_t color) {
    if (y < 0 || y >= PBC_HEIGHT) return;
    if (x < 0) { length += x; x = 0; }
    if (x + length > PBC_WIDTH) length = PBC_WIDTH - x;
    uint16_t *p = &pbc_bildpuffer[y * PBC_WIDTH + x];
    for (int i = 0; i < length; i++) p[i] = color;
}

void pbc_vline(int x, int y, int length, uint16_t color) {
    if (x < 0 || x >= PBC_WIDTH) return;
    if (y < 0) { length += y; y = 0; }
    if (y + length > PBC_HEIGHT) length = PBC_HEIGHT - y;
    for (int i = 0; i < length; i++) pbc_bildpuffer[(y + i) * PBC_WIDTH + x] = color;
}

// Bresenham: geht Pixel für Pixel von (x1, y1) nach (x2, y2).
void pbc_line(int x1, int y1, int x2, int y2, uint16_t color) {
    if (y1 == y2) {
        pbc_hline(x1 < x2 ? x1 : x2, y1, abs(x2 - x1) + 1, color);
        return;
    }
    if (x1 == x2) {
        pbc_vline(x1, y1 < y2 ? y1 : y2, abs(y2 - y1) + 1, color);
        return;
    }
    int dx = abs(x2 - x1), dy = -abs(y2 - y1);
    int sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1;
    int err = dx + dy;
    for (;;) {
        pbc_pixel(x1, y1, color);
        if (x1 == x2 && y1 == y2) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x1 += sx; }
        if (e2 <= dx) { err += dx; y1 += sy; }
    }
}

// ---- Rechtecke --------------------------------------------------------------

void pbc_rect(int x, int y, int w, int h, uint16_t color) {
    if (w <= 0 || h <= 0) return;
    pbc_hline(x, y, w, color);
    pbc_hline(x, y + h - 1, w, color);
    pbc_vline(x, y + 1, h - 2, color);
    pbc_vline(x + w - 1, y + 1, h - 2, color);
}

void pbc_fill_rect(int x, int y, int w, int h, uint16_t color) {
    for (int i = 0; i < h; i++) pbc_hline(x, y + i, w, color);
}

// ---- Ellipsen und Kreise ------------------------------------------------------

// Die vier gespiegelten Punkte (oder Linien) eines Ellipsen-Schritts.
// Gefüllt: je Viertel eine waagrechte Linie vom Mittelpunkt nach außen.
static void ellipse_punkte(int mx, int my, int x, int y, uint16_t color, bool fill) {
    if (fill) {
        pbc_hline(mx, my - y, x + 1, color);
        pbc_hline(mx - x, my - y, x + 1, color);
        pbc_hline(mx - x, my + y, x + 1, color);
        pbc_hline(mx, my + y, x + 1, color);
    } else {
        pbc_pixel(mx + x, my - y, color);
        pbc_pixel(mx - x, my - y, color);
        pbc_pixel(mx - x, my + y, color);
        pbc_pixel(mx + x, my + y, color);
    }
}

// Derselbe Algorithmus wie framebuf.ellipse in MicroPython (nach
// J. Kennedy): erst die steilen Stücke an den Seiten, dann die flachen
// oben und unten. Es wird nur mit ganzen Zahlen gerechnet.
static void ellipse(int mx, int my, int rx, int ry, uint16_t color, bool fill) {
    if (rx == 0 && ry == 0) {
        pbc_pixel(mx, my, color);
        return;
    }
    long two_a2 = 2L * rx * rx, two_b2 = 2L * ry * ry;
    long x = rx, y = 0;
    long xchange = (long)ry * ry * (1 - 2L * rx), ychange = (long)rx * rx;
    long fehler = 0, stopx = two_b2 * rx, stopy = 0;
    while (stopx >= stopy) {
        ellipse_punkte(mx, my, (int)x, (int)y, color, fill);
        y++;
        stopy += two_a2;
        fehler += ychange;
        ychange += two_a2;
        if (2 * fehler + xchange > 0) {
            x--;
            stopx -= two_b2;
            fehler += xchange;
            xchange += two_b2;
        }
    }
    x = 0;
    y = ry;
    xchange = (long)ry * ry;
    ychange = (long)rx * rx * (1 - 2L * ry);
    fehler = 0;
    stopx = 0;
    stopy = two_a2 * ry;
    while (stopx <= stopy) {
        ellipse_punkte(mx, my, (int)x, (int)y, color, fill);
        x++;
        stopx += two_b2;
        fehler += xchange;
        xchange += two_b2;
        if (2 * fehler + ychange > 0) {
            y--;
            stopy -= two_a2;
            fehler += ychange;
            ychange += two_a2;
        }
    }
}

void pbc_ellipse(int mx, int my, int rx, int ry, uint16_t color) { ellipse(mx, my, rx, ry, color, false); }
void pbc_fill_ellipse(int mx, int my, int rx, int ry, uint16_t color) { ellipse(mx, my, rx, ry, color, true); }
void pbc_circle(int mx, int my, int r, uint16_t color) { ellipse(mx, my, r, r, color, false); }
void pbc_fill_circle(int mx, int my, int r, uint16_t color) { ellipse(mx, my, r, r, color, true); }

// ---- Text ---------------------------------------------------------------------

// 8 × 8: jedes Zeichen sind 8 Spalten zu je 8 Bit, Bit 0 = oberste Zeile.
int pbc_text(const char *s, int x, int y, uint16_t color) {
    for (; *s; s++, x += 8) {
        unsigned char c = (unsigned char)*s;
        if (c < 32 || c > 127) c = '?';
        const uint8_t *g = &font_petme128_8x8[(c - 32) * 8];
        for (int spalte = 0; spalte < 8; spalte++) {
            for (int zeile = 0; zeile < 8; zeile++) {
                if (g[spalte] & (1 << zeile)) pbc_pixel(x + spalte, y + zeile, color);
            }
        }
    }
    return x;
}

int pbc_text_width(const char *s) {
    return 8 * (int)strlen(s);
}

// Die drei Proportionalschriften sind gleich aufgebaut: je Zeichen eine
// Breite und Zeilen aus 2 oder 3 Bytes, Bit 0 des ersten Bytes = linkes Pixel.
typedef struct {
    const uint8_t *breiten;
    const uint8_t *daten;
    int hoehe, bytes_pro_zeile, bytes_pro_zeichen;
} schrift;

static const schrift S12 = { font12_widths, font12_data, FONT12_HEIGHT, FONT12_ROW_BYTES, FONT12_BYTES_PER_GLYPH };
static const schrift S18 = { font18_widths, font18_data, FONT18_HEIGHT, FONT18_ROW_BYTES, FONT18_BYTES_PER_GLYPH };
static const schrift S24 = { font24_widths, font24_data, FONT24_HEIGHT, FONT24_ROW_BYTES, FONT24_BYTES_PER_GLYPH };

static int text_prop(const schrift *f, const char *s, int x, int y, uint16_t color) {
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c < 32 || c > 127) c = '?';
        int breite = f->breiten[c - 32];
        const uint8_t *g = &f->daten[(c - 32) * f->bytes_pro_zeichen];
        for (int zeile = 0; zeile < f->hoehe; zeile++) {
            const uint8_t *z = &g[zeile * f->bytes_pro_zeile];
            uint32_t bits = z[0] | (z[1] << 8);
            if (f->bytes_pro_zeile == 3) bits |= (uint32_t)z[2] << 16;
            for (int spalte = 0; spalte < breite; spalte++) {
                if (bits & (1u << spalte)) pbc_pixel(x + spalte, y + zeile, color);
            }
        }
        x += breite + 1;   // 1 Pixel Abstand zwischen den Zeichen
    }
    return x;
}

static int breite_prop(const schrift *f, const char *s) {
    int w = 0;
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c < 32 || c > 127) c = '?';
        w += f->breiten[c - 32] + 1;
    }
    return w > 0 ? w - 1 : 0;
}

int pbc_text12(const char *s, int x, int y, uint16_t color) { return text_prop(&S12, s, x, y, color); }
int pbc_text18(const char *s, int x, int y, uint16_t color) { return text_prop(&S18, s, x, y, color); }
int pbc_text24(const char *s, int x, int y, uint16_t color) { return text_prop(&S24, s, x, y, color); }
int pbc_text12_width(const char *s) { return breite_prop(&S12, s); }
int pbc_text18_width(const char *s) { return breite_prop(&S18, s); }
int pbc_text24_width(const char *s) { return breite_prop(&S24, s); }

// ---- Bilder ---------------------------------------------------------------------

void pbc_draw_image(const pbc_image *image, int x, int y) {
    for (int zeile = 0; zeile < image->height; zeile++) {
        for (int spalte = 0; spalte < image->width; spalte++) {
            int i = zeile * image->width + spalte;
            if (image->mask == NULL || image->mask[i]) {
                pbc_pixel(x + spalte, y + zeile, image->pixels[i]);
            }
        }
    }
}

// ---- Zufall und Konsole (für Gerät und PC gleich) ---------------------------------

int pbc_random(int min, int max) {
    if (max < min) { int t = min; min = max; max = t; }
    return min + (int)(pbc_zufall32() % (uint32_t)(max - min + 1));
}

void pbc_input(const char *prompt, char *text, int size) {
    printf("%s", prompt);
    fflush(stdout);
    // Enter kommt je nach Monitor als '\r', '\n' oder "\r\n". Ein '\n' direkt
    // nach einem '\r' gehört noch zur vorigen Zeile und wird übergangen.
    static bool zuletzt_cr = false;
    int n = 0;
    for (;;) {
        int c = pbc_zeichen_lesen();
        if (c == '\n' && zuletzt_cr) {
            zuletzt_cr = false;
            continue;
        }
        zuletzt_cr = (c == '\r');
        if (c == '\r' || c == '\n') break;
        if (c == 8 || c == 127) {             // Rücktaste
            if (n > 0) { n--; printf("\b \b"); fflush(stdout); }
            continue;
        }
        if (c < 32 || n >= size - 1) continue;
        text[n++] = (char)c;
        putchar(c);                           // das Getippte anzeigen
        fflush(stdout);
    }
    text[n] = '\0';
    printf("\n");
}

int pbc_input_int(const char *prompt) {
    char text[32];
    pbc_input(prompt, text, sizeof text);
    return atoi(text);
}

float pbc_input_float(const char *prompt) {
    char text[32];
    pbc_input(prompt, text, sizeof text);
    for (char *p = text; *p; p++) if (*p == ',') *p = '.';
    return strtof(text, NULL);
}
